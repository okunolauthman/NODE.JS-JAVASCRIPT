PROJECT 1(JAVASCRIPT)
 
Language Javascript
Requirement
Install Node.js and Visual Studios Code

Project Description: This is a slot machine that has three line and spins, we take user input and match them with the result of the wheel. We asses balance, user input, input validation and while loops to ensure user stay interested in the slot machine


STEP 1
Open visual studio code
Create a folder and name it
Set up a node directory which will allow us to import a package to get user input
Open Terminal from the current Visual studio file ie current path should match where project folder is stored.

Type command: npm init
You click “Enter” until a package.json file appears in the folder

Then type and enter command npm i prompt-sync in the same terminal (This is what is used to collect user input) - 3 files are installed

Step 1 is completed and we can start writing our code.




STEP 2
 Start coding. Check the file path to see the code.
Sometimes you need to run the debugger for node js to run the program
To run the file you go to the terminal and you type: “node project.js” where project.js is the file name. 
-- COMPLETED
